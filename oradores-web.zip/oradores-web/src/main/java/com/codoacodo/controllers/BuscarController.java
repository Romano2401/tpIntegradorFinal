package com.codoacodo.controllers;

import com.codoacodo.model.Orador;
import com.codocodo.dao.OradorDAO;
import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/api/BuscarController")
public class BuscarController extends HttpServlet {
	
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String clave = req.getParameter("clave");
		
		OradorDAO dao = new OradorDAO();
		
		List<Orador> listado = dao.buscar(clave);
		
		req.setAttribute("listado", listado);
		
		getServletContext().getRequestDispatcher("/assets/pages/listado.jsp").forward(req, resp);
	}
}

