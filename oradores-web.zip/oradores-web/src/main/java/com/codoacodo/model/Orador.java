package com.codoacodo.model;

import java.sql.Timestamp;

public class Orador extends Persona {
    
    private String tema;
    private Timestamp fechaAlta;
    
    public Orador () {}

    public Orador(Long idPersona, String nombre, String apellido, String mail, String tema, Timestamp fechaAlta ) {
        super(idPersona, nombre, apellido, mail);
        this.tema = tema;
        this.fechaAlta = fechaAlta;
    }
    
    public Orador(String nombre, String apellido , String mail, String tema) {
        super(nombre,apellido,mail);
        this.tema = tema;
    }
    
    public String getTema() {
        return tema;
    }

    public void setTema(String tema) {
        this.tema = tema;
    }

    public Timestamp getFechaAlta() {
        return fechaAlta;
    }

    public void setFechaAlta(Timestamp fechaAlta) {
        this.fechaAlta = fechaAlta;
    }
    
    @Override
    public String toString() {
        return super.toString() + "Orador{" + "tema=" + tema + " - Fecha de Alta=" + fechaAlta +'}';
    }
}
