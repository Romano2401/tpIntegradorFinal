    package com.codoacodo.model;

public class Persona {
    
    private Long idPersona;
    private String nombre;
    private String apellido;
    private String mail;
    
    public Persona(){}
    
    public Persona(String nombre, String apellido) {
        this.nombre = nombre;
        this.apellido = apellido;
    }
    
    public Persona(Long idPersona, String nombre, String apellido, String mail) {
        this.idPersona = idPersona;
        this.nombre = nombre;
        this.apellido = apellido;
        this.mail = mail;
    }
    
    public Persona(String nombre, String apellido, String mail) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.mail = mail;
    }
    
    
    public Long getIdPersona() {
        return idPersona;
    }
    
    public void setIdPersona(Long idPersona) {
        this.idPersona = idPersona;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }
    
    @Override
    public String toString() {
        return "Persona{" + "id=" + idPersona + ", nombre=" + nombre + ", apellido=" + apellido + '}';
    }

}
