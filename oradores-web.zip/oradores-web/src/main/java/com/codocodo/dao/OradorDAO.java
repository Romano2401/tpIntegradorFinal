package com.codocodo.dao;

import com.codoacodo.connection.AdministradorDeConexiones;
import com.codoacodo.model.Orador;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class OradorDAO { 
    
    private static final String SQL_DELETE = "DELETE FROM oradores WHERE ID = ?";
    
	public Orador obtenerPorId(Long idPers) {
		String sql = "SELECT * FROM oradores WHERE ID="+idPers;
		
		
		Connection con = AdministradorDeConexiones.getConnection();
	
		Orador oradFromDb = null;
		
		try {
			Statement st = con.createStatement();
			
			ResultSet rs = st.executeQuery(sql);
			
			if(rs.next()) {
                            
                            Long idPersona = rs.getLong(1);
                            String nombre = rs.getString(2);
                            String apellido = rs.getString(3);
                            String mail = rs.getString(4);
                            String tema = rs.getString(5);
                            Timestamp fechaAlta = rs.getTimestamp(6);
                        
			oradFromDb = new Orador(idPersona,nombre,apellido,mail,tema,fechaAlta);
			}			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return oradFromDb;
	}

	public List<Orador> listarOrador() {
		String sql = "SELECT * FROM oradores ";
		
		Connection con = AdministradorDeConexiones.getConnection();
	
		List<Orador> list = new ArrayList<>();

		try {
			Statement st = con.createStatement();
			

			ResultSet rs = st.executeQuery(sql);
	
			
			while(rs.next()) {//
		            Long idPersona = rs.getLong(1);
                            String nombre = rs.getString(2);
                            String apellido = rs.getString(3);
                            String mail = rs.getString(4);
                            String tema = rs.getString(5);
                            Timestamp fechaAlta = rs.getTimestamp(6);
                        
			    Orador oradFromDb = new Orador(idPersona,nombre,apellido,mail,tema,fechaAlta); 
			    list.add(oradFromDb);
			}			
			
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	public void crearOrador(String nombre, String apellido, String mail, String tema) {
		
		Connection con = AdministradorDeConexiones.getConnection();
		
		if(con != null) { 
		
			String sql = "INSERT INTO oradores (nombre, apellido, mail, tema) ";
			sql += "VALUES('"+nombre+"','"+apellido+"','"+mail+"','"+tema+"')";
			
			try {
				Statement st = con.createStatement();			
				st.execute(sql);

				con.close();
				
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public void actualizarOrador(String nombre, String apellido, String mail, String tema) {
		Connection con = AdministradorDeConexiones.getConnection();
		if(con != null) { 
			String sql = "UPDATE oradores "
					+ " set nombre='"+nombre+"',"
					+ " apellido='"+apellido+"',"
					+ " mail='"+mail+"'"
					+ " WHERE tema = '"+tema+"'";		
		
			try {
				Statement st = con.createStatement();			
				st.executeUpdate(sql);
				con.close();
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
        
	public List<Orador> buscar(String clave) {
		String sql = "SELECT * FROM oradores WHERE nombre LIKE '%"+clave+"%' ";
                        
		Connection con = AdministradorDeConexiones.getConnection();
	
		List<Orador> listado = new ArrayList<Orador>();
	
		try {
			Statement st = con.createStatement();
			
			ResultSet rs = st.executeQuery(sql);
			
			
			while(rs.next()) {
                            Long idPersona = rs.getLong(1);
                            String nombre = rs.getString(2);
                            String apellido = rs.getString(3);
                            String mail = rs.getString(4);
                            String tema = rs.getString(5);
                            Timestamp fechaAlta = rs.getTimestamp(6);
                        
			    Orador oradFromDb = new Orador(idPersona,nombre,apellido,mail,tema,fechaAlta); 
			    listado.add(oradFromDb);
			}			
                        }
		 catch (SQLException e) {
			e.printStackTrace();
		}
		return listado;
	}
        
        public int eliminarOrador(int id) {
        Connection conn = null;
        PreparedStatement stmt = null;
        int registros = 0;
        
        try{
            conn = AdministradorDeConexiones.getConnection();
            stmt = conn.prepareStatement(SQL_DELETE);
            stmt.setInt(1, id);
            registros = stmt.executeUpdate();
        } catch(SQLException | NullPointerException ex) {
            ex.printStackTrace(System.out);
        } finally {
            try {
                stmt.close();
                conn.close();
            } catch(SQLException | NullPointerException ex) {
                ex.printStackTrace(System.out);
            }
        }
        
        return registros;
    }
    
}